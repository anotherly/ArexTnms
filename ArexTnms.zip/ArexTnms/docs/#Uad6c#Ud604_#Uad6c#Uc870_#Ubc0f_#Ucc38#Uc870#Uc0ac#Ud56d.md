# 구현 구조 및 코레일 소스 참조사항

| 구분 | 코레일 참조 방식 | TNMS 적용 |
|---|---|---|
| 계층 구조 | Controller → Service → Mapper → XML | 동일 구조 유지 |
| VO | 상위 조직 VO를 상속 | 공통 검색·등록 필드를 가진 `BaseVO` 상속 |
| 비밀번호 | BCrypt | BCrypt 10 round, 평문 미저장 |
| 세션 | `SessionListener`로 사용자-세션 관리 | 중복 로그인 시 이전 세션 종료 |
| 접근 제어 | URL 목록 기반 `AuthInterceptor` | 메뉴별 LIST/DTL/REG/MDFCN/DEL/CTRL 검사 |
| 권한 저장 | 권한별 URL 사용 여부 | `web_authrt_menu_rel`의 기능별 Y/N 사용 |
| 반복 처리 | 각 Controller에 유사 코드 | 작업로그는 `AuditService`로 공통화 |

현재 데이터베이스 스키마의 테이블명과 컬럼명은 `web_user_info`, `web_authrt_info`, `web_menu_info`, `web_authrt_menu_rel`, `user_authrt_rel`을 그대로 사용합니다. 코레일 테이블명이나 컬럼명은 가져오지 않았습니다.

시스템 관리자 권한(`AUTHRT_SN=1`)과 해당 권한을 가진 계정은 삭제·권한 해제 대상에서 보호합니다. 권한 변경은 인터셉터가 매 요청마다 DB를 다시 조회하므로 재로그인 없이 접근 제어에 반영됩니다.
