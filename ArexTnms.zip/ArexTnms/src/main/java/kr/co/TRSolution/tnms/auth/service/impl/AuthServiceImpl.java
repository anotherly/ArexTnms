package kr.co.TRSolution.tnms.auth.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import kr.co.TRSolution.tnms.auth.mapper.AuthMapper;
import kr.co.TRSolution.tnms.auth.service.AuthService;
import kr.co.TRSolution.tnms.auth.vo.AuthVO;
import kr.co.TRSolution.tnms.auth.vo.MenuAuthVO;
import kr.co.TRSolution.tnms.auth.vo.SystemAuthVO;

@Service("authService")
public class AuthServiceImpl implements AuthService {
    private static final String SYSTEM_ADMIN_AUTHRT_CD = "SYS_ADMIN";
    private static final Pattern AUTHRT_CD = Pattern.compile("^[A-Z][A-Z0-9_]{2,29}$");

    @Resource(name = "authMapper")
    private AuthMapper authMapper;
    @Resource(name="systemCodeRegistry") private kr.co.TRSolution.tnms.gateway.service.SystemCodeRegistry codes;

    @Override
    public List<AuthVO> selectAuthList() { return authMapper.selectAuthList(); }

    @Override
    public AuthVO selectAuth(String authrtCd) {
        String code = normalizeCode(authrtCd);
        AuthVO auth = authMapper.selectAuth(code);
        if (auth == null) throw new IllegalArgumentException("존재하지 않는 권한입니다.");
        List<MenuAuthVO> menuAuthList = authMapper.selectMenuAuthList(code);
        if (SYSTEM_ADMIN_AUTHRT_CD.equals(code)) {
            for (MenuAuthVO menu : menuAuthList) normalizePermission(menu, true);
        }
        auth.setMenuAuthList(menuAuthList);
        List<SystemAuthVO> systemAuthList = authMapper.selectSystemAuthList(code);
        if (SYSTEM_ADMIN_AUTHRT_CD.equals(code)) for (SystemAuthVO item : systemAuthList) item.setReadAuthrtYn("Y");
        auth.setSystemAuthList(systemAuthList);
        return auth;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public AuthVO createAuth(AuthVO authVO, String actorId) {
        normalizeAndValidate(authVO, true);
        authVO.setUseYn("Y");
        authVO.setRgtrId(actorId);
        if (authMapper.countAuthCode(authVO) > 0) throw new IllegalArgumentException("이미 사용 중인 권한코드입니다.");
        if (authMapper.countAuthName(authVO) > 0) throw new IllegalArgumentException("이미 사용 중인 권한명입니다.");
        if (authMapper.insertAuth(authVO) != 1) throw new IllegalStateException("권한 등록에 실패했습니다.");
        return authVO;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateAuth(AuthVO authVO, String actorId) {
        normalizeAndValidate(authVO, false);
        if (SYSTEM_ADMIN_AUTHRT_CD.equals(authVO.getAuthrtCd())) {
            throw new IllegalArgumentException("시스템 관리자 권한은 수정할 수 없습니다.");
        }
        AuthVO existing = authMapper.selectAuth(authVO.getAuthrtCd());
        if (existing == null) throw new IllegalArgumentException("수정할 권한이 없습니다.");
        authVO.setMdfrId(actorId);
        authVO.setUseYn("Y");
        if (authMapper.countAuthName(authVO) > 0) throw new IllegalArgumentException("이미 사용 중인 권한명입니다.");
        if (authMapper.updateAuth(authVO) != 1) throw new IllegalStateException("권한 수정에 실패했습니다.");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteAuth(String authrtCd, String actorId) {
        String code = normalizeCode(authrtCd);
        if (SYSTEM_ADMIN_AUTHRT_CD.equals(code)) throw new IllegalArgumentException("시스템 관리자 권한은 삭제할 수 없습니다.");
        if (authMapper.selectAuth(code) == null) throw new IllegalArgumentException("삭제할 권한이 없습니다.");
        if (authMapper.countAuthUsers(code) > 0) throw new IllegalStateException("해당 권한을 사용 중인 사용자가 있습니다.");
        authMapper.deleteAuthMenus(code);
        authMapper.deleteSystemAuths(code);
        AuthVO auth = new AuthVO();
        auth.setAuthrtCd(code);
        auth.setMdfrId(actorId);
        if (authMapper.disableAuth(auth) != 1) throw new IllegalStateException("권한 삭제에 실패했습니다.");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void saveMenuPermissions(String authrtCd, List<MenuAuthVO> permissions, List<SystemAuthVO> systemAuthList) {
        String code = normalizeCode(authrtCd);
        if (authMapper.selectAuth(code) == null) throw new IllegalArgumentException("권한 정보가 없습니다.");
        if (SYSTEM_ADMIN_AUTHRT_CD.equals(code)) {
            throw new IllegalArgumentException("시스템 관리자 메뉴 권한은 변경할 수 없습니다.");
        }
        Map<Long, String> screenByMenuSn = new HashMap<Long, String>();
        for (MenuAuthVO menu : authMapper.selectMenuAuthList(code)) screenByMenuSn.put(menu.getMenuSn(), menu.getScreenKey());
        authMapper.deleteAuthMenus(code);
        if (permissions != null) for (MenuAuthVO permission : permissions) {
            if (permission.getMenuSn() == null || !screenByMenuSn.containsKey(permission.getMenuSn())) continue;
            permission.setAuthrtCd(code);
            permission.setScreenKey(screenByMenuSn.get(permission.getMenuSn()));
            normalizePermission(permission, SYSTEM_ADMIN_AUTHRT_CD.equals(code));
            authMapper.insertMenuAuth(permission);
        }
        // 메뉴/시스템 조회 범위는 단일 트랜잭션으로 함께 저장합니다.
        if (systemAuthList != null) {
            authMapper.deleteSystemAuths(code);
            Set<String> seen = new HashSet<String>();
            for (SystemAuthVO item : systemAuthList) {
                if (item == null || !codes.allCodes().contains(item.getLinkSysCd()) || !seen.add(item.getLinkSysCd()))
                    throw new IllegalArgumentException("올바르지 않은 연계시스템 권한입니다.");
                if ("Y".equals(item.getReadAuthrtYn())) {
                    Map<String, Object> params = new HashMap<String, Object>();
                    params.put("authrtCd", code);
                    params.put("linkSysCd", item.getLinkSysCd());
                    authMapper.insertSystemAuth(params);
                }
            }
        }
    }

    @Override
    public List<String> selectAllowedSystemCodes(String authrtCd) {
        if (SYSTEM_ADMIN_AUTHRT_CD.equals(normalizeCode(authrtCd))) return new ArrayList<String>(codes.allCodes());
        List<String> allowed = new ArrayList<String>();
        for (SystemAuthVO item : authMapper.selectSystemAuthList(normalizeCode(authrtCd))) {
            if (codes.allCodes().contains(item.getLinkSysCd()) && "Y".equals(item.getReadAuthrtYn())) allowed.add(item.getLinkSysCd());
        }
        return allowed;
    }

    @Override
    public Map<String, MenuAuthVO> selectPermissionMap(String authrtCd) {
        Map<String, MenuAuthVO> map = new LinkedHashMap<String, MenuAuthVO>();
        String code = normalizeCode(authrtCd);
        for (MenuAuthVO item : authMapper.selectMenuAuthList(code)) {
            if (SYSTEM_ADMIN_AUTHRT_CD.equals(code)) normalizePermission(item, true);
            map.put(item.getScreenKey(), item);
        }
        return map;
    }

    private void normalizeAndValidate(AuthVO auth, boolean create) {
        String code = normalizeCode(auth.getAuthrtCd());
        if (code == null || !AUTHRT_CD.matcher(code).matches()) {
            throw new IllegalArgumentException("권한코드는 영문 대문자로 시작하고 영문 대문자·숫자·밑줄 조합 3~30자로 입력해 주세요.");
        }
        auth.setAuthrtCd(code);
        String name = auth.getAuthrtNm() == null ? "" : auth.getAuthrtNm().trim();
        if (name.length() == 0 || name.length() > 100) throw new IllegalArgumentException("권한명은 1~100자로 입력해 주세요.");
        auth.setAuthrtNm(name);
        if (auth.getAuthrtExpln() != null && auth.getAuthrtExpln().length() > 4000) {
            throw new IllegalArgumentException("권한설명은 4,000자 이내로 입력해 주세요.");
        }
        if (!create && SYSTEM_ADMIN_AUTHRT_CD.equals(code)) auth.setUseYn("Y");
    }

    private String normalizeCode(String value) {
        if (value == null) return null;
        String code = value.trim().toUpperCase();
        return code.length() == 0 ? null : code;
    }

    private void normalizePermission(MenuAuthVO item, boolean systemAdmin) {
        String screen = item.getScreenKey();
        item.setDisplayYn(systemAdmin || "Y".equals(item.getDisplayYn()) ? "Y" : "N");
        item.setListAuthrtYn(systemAdmin || "Y".equals(item.getListAuthrtYn()) ? "Y" : "N");
        item.setDtlAuthrtYn(supports(screen, "DTL") && (systemAdmin || "Y".equals(item.getDtlAuthrtYn())) ? "Y" : "N");
        item.setRegAuthrtYn(supports(screen, "REG") && (systemAdmin || "Y".equals(item.getRegAuthrtYn())) ? "Y" : "N");
        item.setMdfcnAuthrtYn(supports(screen, "MDFCN") && (systemAdmin || "Y".equals(item.getMdfcnAuthrtYn())) ? "Y" : "N");
        item.setDelAuthrtYn(supports(screen, "DEL") && (systemAdmin || "Y".equals(item.getDelAuthrtYn())) ? "Y" : "N");
        item.setCtrlAuthrtYn("N");
        if ("Y".equals(item.getMdfcnAuthrtYn()) || "Y".equals(item.getDelAuthrtYn())) item.setDtlAuthrtYn("Y");
        if ("Y".equals(item.getDtlAuthrtYn()) || "Y".equals(item.getRegAuthrtYn()) ||
            "Y".equals(item.getMdfcnAuthrtYn()) || "Y".equals(item.getDelAuthrtYn())) item.setListAuthrtYn("Y");
    }

    private boolean supports(String screen, String action) {
        if (screen == null) return "LIST".equals(action);
        if ("systems".equals(screen) || "equipment".equals(screen) || "scada".equals(screen) ||
            "switch".equals(screen) || "cctv".equals(screen) || "users".equals(screen) || "auth".equals(screen)) return true;
        if ("settings".equals(screen)) return "LIST".equals(action) || "REG".equals(action) || "MDFCN".equals(action);
        if ("logs".equals(screen) || "performance".equals(screen) || "faultTypes".equals(screen))
            return "LIST".equals(action) || "DTL".equals(action);
        if ("cycle".equals(screen))
            return "LIST".equals(action) || "DTL".equals(action) || "REG".equals(action) ||
                   "MDFCN".equals(action) || "DEL".equals(action);
        if ("threshold".equals(screen) ||
            "faults".equals(screen) || "faultHistory".equals(screen))
            return "LIST".equals(action) || "DTL".equals(action) || "MDFCN".equals(action);
        if ("exceptions".equals(screen))
            return "LIST".equals(action) || "DTL".equals(action) || "REG".equals(action) ||
                   "MDFCN".equals(action) || "DEL".equals(action);
        return "LIST".equals(action);
    }

    private String yn(String value) { return "Y".equals(value) ? "Y" : "N"; }
}
