<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="true" %>
<%
request.setAttribute("pageKey", "faultTypes");
request.setAttribute("pageTitle", "장애유형 관리");
request.setAttribute("pageDescription", "설비 EMS에서 연동되는 장애유형, 등급, 판단기준과 사용여부를 관리합니다.");
%>
<!doctype html>
<html lang="ko">
<head>
  <jsp:include page="/WEB-INF/jsp/common/common-resources.jsp" />
  <link rel="stylesheet" href="<%=request.getContextPath()%>/css/tnms/management-screen.css?v=20261010.2" />
</head>
<body>
<div class="app">
  <jsp:include page="/WEB-INF/jsp/common/menu.jsp" />
  <main class="main">
    <jsp:include page="/WEB-INF/jsp/common/header.jsp" />
    <section class="content">
      <div class="heading">
        <div><h1>장애유형 관리</h1><p>설비 EMS에서 연동되는 장애유형, 등급, 판단기준과 사용여부를 관리합니다.</p></div>
        <div class="actions page-actions" id="pageActions"></div>
      </div>
      <div id="pageBody"></div>
    </section>
  </main>
</div>
<jsp:include page="/WEB-INF/jsp/common/common-scripts.jsp" />
<script src="<%=request.getContextPath()%>/js/tnms/pages/management-common.js?v=20261010.1"></script>
<script src="<%=request.getContextPath()%>/js/tnms/pages/fault/types.js?v=20261010.2"></script>
</body>
</html>
