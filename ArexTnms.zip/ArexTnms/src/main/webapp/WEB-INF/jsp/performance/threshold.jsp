<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="true" %>
<%
request.setAttribute("pageKey", "threshold");
request.setAttribute("pageTitle", "임계치 관리");
request.setAttribute("pageDescription", "CPU·MEMORY 성능지표의 실제 장애등급 기반 다단계 임계치를 설정합니다.");
%>
<!doctype html>
<html lang="ko">
<head>
  <jsp:include page="/WEB-INF/jsp/common/common-resources.jsp" />
  <link rel="stylesheet" href="<%=request.getContextPath()%>/css/tnms/management-screen.css?v=20261106.4" />
</head>
<body>
<div class="app">
  <jsp:include page="/WEB-INF/jsp/common/menu.jsp" />
  <main class="main">
    <jsp:include page="/WEB-INF/jsp/common/header.jsp" />
    <section class="content">
      <div class="heading">
        <div><h1>임계치 관리</h1><p>CPU·MEMORY 성능지표의 실제 장애등급 기반 다단계 임계치를 설정합니다.</p></div>
        <div class="actions page-actions" id="pageActions"></div>
      </div>
      <div id="pageBody"></div>
    </section>
  </main>
</div>
<jsp:include page="/WEB-INF/jsp/common/common-scripts.jsp" />
<script src="<%=request.getContextPath()%>/js/tnms/pages/management-common.js?v=20261106.4"></script>
<script src="<%=request.getContextPath()%>/js/tnms/pages/performance/threshold.js?v=20261106.4"></script>
</body>
</html>
